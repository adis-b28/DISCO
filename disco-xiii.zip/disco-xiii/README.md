# DISCO XIII — Pixel Fine Dining

Author: Adis

Paket website statis dengan empat halaman: Beranda, Tentang, Divisi, dan Dokumentasi.

## Menjalankan

Buka dist/index.html atau jalankan dari folder paket:

```sh
python3 -m http.server 4317 --directory dist
```

Buka http://localhost:4317.

## Desain dan berkas utama

- fine-dining.css: warna burgundy, emas, gading, tipografi fine dining dan detail pixel.
- background.js: animasi restoran malam dari file pengguna.
- app.js: sapaan maskot, sembilan bab divisi, tiga lembar album dokumentasi.
- assets/mascot-host-fine.png dan mascot-camera-fine.png: maskot pixel bertema fine dining.
- Logo utama dipertahankan. Sembilan lambang divisi menggunakan bagian gambar 00-semua-logo.png dari pengguna dengan potongan CSS yang menjaga pixel asli. Semua informasi divisi tetap tersedia.

Buku menu Divisi dapat dipilih melalui nama bab atau tombol sebelumnya/berikutnya. Pergantian bab Divisi dan lembar Dokumentasi memakai animasi lipatan kertas 3D berdurasi sekitar 620 ms, arah maju/mundur mengikuti navigasi, dengan garis lipatan bertepi pixel. Reduced motion melewati animasi dan langsung menampilkan isi. Album menampilkan dua foto per lembar. Tanpa JavaScript seluruh informasi dan foto tetap tampil. Animasi menghormati reduced motion. Tidak ada tombol jeda, sponsor, atau tautan kembali ke situs sumber. Tidak ada sistem akun, reservasi, pembayaran, atau pendaftaran.

## Materi

Informasi publik dan dokumentasi DISCO XIII berasal dari situs DISCO yang diberikan pengguna, dibaca 13 November 2026. Tanggal edisi XIII adalah 6–8 November 2026. Tema restoran adalah presentasi visual dari acara DISCO, tidak mengubah identitas kegiatan menjadi restoran komersial.

Latar: Restoran Malam Pixel Art.html dari pengguna. Maskot: referensi asli DISCO diubah busananya menjadi fine dining; identitas wajah tetap dipertahankan. Font Cormorant Garamond, Chivo, dan Pixelify Sans melalui Google Fonts membutuhkan internet; fallback lokal tersedia.

## Pemeriksaan

Navigasi dan aset lokal diperiksa. Logika pemilihan sembilan divisi, batas tombol sebelumnya/berikutnya, dan album enam foto diuji. Tampilan desktop dan ponsel dirender dan diperiksa.
